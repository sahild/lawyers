<?php
/**
 * @package WordPress
 * @subpackage Lawyers
 */
?>
		<div class="col-md-4">
		<aside>
        
		<ul>
			<?php 	/* Widgetized sidebar, if you have the plugin installed. */
					if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>
			
			<?php endif; ?>
 
  	</ul>    
    

</aside><!-- end sidebar -->
</div><!--.col-md-4-->