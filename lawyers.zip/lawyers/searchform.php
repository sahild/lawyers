<form method="get" id="search-form" action="<?php echo home_url(); ?>/">
	<span><input type="text" name="s" id="search-string" placeholder="<?php _e('type and hit enter', 'match')?>"/></span>
</form>
